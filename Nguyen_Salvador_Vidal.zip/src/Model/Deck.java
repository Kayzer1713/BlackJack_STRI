package Model;

import java.util.ArrayList;

public class Deck {

	public ArrayList<Carte> listeCartes = null;

	public Deck() {
		this.reset();
	}

	public void reset() {
	}

	public void melange() {
	}

	public void prendreCarte() {
	}

}
