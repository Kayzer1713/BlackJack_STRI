package Model;

import java.util.ArrayList;

public class Joueur {
	
	/**
	 * Liste des cartes en main du joueur
	 */
	public ArrayList<Carte> main = null;
	
	/**
	 * Bool�en signifiant si le joueur est �limin� ou non
	 */
	public Boolean horsJeu;
	
	/**
	 * pseudo/nom du joueur
	 */
	public String nom;

	/**
	 * Constructeur d�fault
	 * @param nom du joueur
	 */
	public Joueur(String n) {
		this.nom = n;
	}

	/**
	 * @return nom du joueur
	 */
	public String getNom() {
		return nom;
	}
	
	/**
	 * @param nom du joueur
	 */
	public void setNom(String nom) 
	{
		this.nom = nom;
	}
	
	/**
	 * 
	 * @return liste des cartes du joueur en main
	 */
	public ArrayList<Carte> getMain() {
		return main;
	}
	
	/**
	 * @param Carte
	 */
	public void ajoutCarte(Carte c) {
		this.main.add(c);
	}
	
	/**
	 * @return si le joueur est encore en jeu
	 */
	public Boolean getHorsJeu() {
		return horsJeu;
	}
	
	/**
	 * @param horsJeu
	 */
	public void setHorsJeu(Boolean horsJeu) {
		this.horsJeu = horsJeu;
	}
	
	/**
	 * remet � z�ro la main du joueur
	 */
	public void reset() {
		this.main.clear();
	}
	
	/**
	 * @return	valeur de la main du joueur
	 */
	public int valeurMain() {
		int val = 0;
		return val;
	}
	
	/**
	 * @return un string d�crivant la main du joueur
	 */
	public String afficheMain() {
		
		return null;
	}

}