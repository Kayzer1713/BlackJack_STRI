package Model;

enum Numero {
	Deux,
	Trois,
	Quatre,
	Cinq,
	Six,
	Sept,
	Huit,
	Neuf,
	Dix,
	Valet,
	Dame,
	Roi,
	As;

}
