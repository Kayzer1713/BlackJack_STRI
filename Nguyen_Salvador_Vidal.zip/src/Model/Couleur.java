package Model;

enum Couleur {
	Trefle,
	Carreau,	
	Coeur,
	Pique;
}